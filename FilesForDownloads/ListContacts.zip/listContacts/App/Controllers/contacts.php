<?php
class ContactsController extends AppController {
	public $uses = array('contacts'); //Carrega o model contacts
	
	public function index(){
		$this->setVar('contacts', $this->contacts->read()); //Seta uma vari�vel na view com todos os dados da tabela contacts
	}
	
	public function add(){
		if($this->input->post()){
			$this->contacts->autoSave();
			$this->redirect('/contacts');
		}
	}
	
	public function edit($id = null){
		$this->setVar('contact', $this->contacts->findByIdContacts($id));
		if($this->input->post() && $id != null){
			$this->contacts->autoSave(array('idContacts' => $id));
			$this->redirect('/contacts');
		}
	}
	
	public function del($id = null){
		if($id != null){
			$this->contacts->delete($id);
			$this->redirect('/contacts');
		}
	}
}