<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $this->pageTitle; echo ($this->pageTitle != null) ? ' -' : ''; ?> Contatos</title>
	</head>
	<body>
		<div id="content">
			<?php echo $this->contentForLayout; ?>
		</div>
	</body>
</html>