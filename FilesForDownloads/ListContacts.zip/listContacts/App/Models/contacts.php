<?php
class Contacts extends AppModel {
	public $table = 'contacts';
	public $primaryKey = 'idContacts';
}