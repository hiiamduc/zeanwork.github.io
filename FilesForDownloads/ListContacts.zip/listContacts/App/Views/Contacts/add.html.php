<h1>Adicionar contato</h1>
<a href="<?php echo Router::url('/contacts')?>">Voltar</a><br /><br />
<?php
$this->load->helper('form');
echo $this->form->start('contact');
echo $this->form->input('name',  array('label' => 'Nome: ', 'divForLabel' => true, 'divForInput' => true)).br();
echo $this->form->input('email',  array('label' => 'E-mail: ', 'divForLabel' => true, 'divForInput' => true)).br();
echo $this->form->input('phone', array('label' => 'Telefone:', 'divForLabel' => true, 'divForInput' => true)).br(2);
echo $this->form->submit('submit', array('value' => 'Postar', 'class' => 'submit'));
echo $this->form->end();