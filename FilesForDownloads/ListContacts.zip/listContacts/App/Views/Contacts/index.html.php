<a href="<?php echo Router::url('/contacts/add')?>">Adicionar</a><br />
<?php
foreach($contacts as $contact):
?>
	<p>
		<b><?php echo $contact['name']?></b> - <?php echo $contact['email']?> - <?php echo $contact['phone']?> <br />
		<a href="<?php echo Router::url('/contacts/edit/'.$contact['idContacts'])?>">Editar</a> - <a href="<?php echo Router::url('/contacts/del/'.$contact['idContacts'])?>">Apagar</a>
	</p>
<?php
endforeach;